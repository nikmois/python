
with open("fruits.txt", "r") as file:
    lines = file.readlines()

for i in range(len(lines)):
    lines[i] = lines[i].replace('\n','')

for i in range(len(lines)-1,-1,-1):
    print(lines[i])
    
#То же самое. Splitlines нарезает на отдельные строчки и удаляет \n
with open("fruits.txt", "r") as file:
    all_lines = file.read()
    lines = all_lines.splitlines()
    
for i in range(len(lines)-1,-1,-1):
    print(lines[i])
    
#Изменяет файл. Добавляет новую строку \n
with open("fruits_reverse.txt", "w") as file:
    for i in range(len(lines)-1,-1,-1):
        file.write(f'{lines[i]}\n')


#Читает файл. Разбивает файл на разные строки. Разбивает строки на разные части по каждой ",".
#Стасит номер для каждой новой части.
lines = []
with open("coords.txt", "r") as file:
    all_lines = file.read()
    lines = all_lines.splitlines()


ctr = 1
for i in lines:
    parts = i.split(",")
    x = float(parts[0])
    y = float(parts[1])
    z = float(parts[2])
    print(f'Point #{ctr} x:{x}, y:{y}, z:{z}')
    ctr += 1